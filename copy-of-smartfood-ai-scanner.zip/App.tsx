
import React, { useState, useRef } from 'react';
import { Goal, AppState, FoodAnalysis } from './types';
import { analyzeFoodImage, getPersonalizedRecommendations } from './services/geminiService';
import MacroChart from './components/MacroChart';
import Loader from './components/Loader';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>({
    isAnalyzing: false,
    goal: Goal.MAINTAIN,
    analysis: null,
    recommendation: null,
    error: null,
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setState(prev => ({ ...prev, isAnalyzing: true, error: null }));

    try {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64 = (reader.result as string).split(',')[1];
        const analysis = await analyzeFoodImage(base64);
        const recommendation = await getPersonalizedRecommendations(analysis, state.goal);

        setState(prev => ({
          ...prev,
          isAnalyzing: false,
          analysis,
          recommendation
        }));
      };
      reader.readAsDataURL(file);
    } catch (err) {
      console.error(err);
      setState(prev => ({ 
        ...prev, 
        isAnalyzing: false, 
        error: "Analysis failed. Ensure the image clearly shows food." 
      }));
    }
  };

  const setGoal = (newGoal: Goal) => {
    setState(prev => ({ ...prev, goal: newGoal }));
    if (state.analysis) {
      updateRecommendations(state.analysis, newGoal);
    }
  };

  const updateRecommendations = async (analysis: FoodAnalysis, goal: Goal) => {
    try {
      setState(prev => ({ ...prev, isAnalyzing: true }));
      const rec = await getPersonalizedRecommendations(analysis, goal);
      setState(prev => ({ ...prev, recommendation: rec, isAnalyzing: false }));
    } catch (err) {
      setState(prev => ({ ...prev, isAnalyzing: false }));
    }
  };

  const reset = () => {
    setState({
      isAnalyzing: false,
      goal: Goal.MAINTAIN,
      analysis: null,
      recommendation: null,
      error: null,
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans pb-20">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2 cursor-pointer" onClick={reset}>
            <div className="bg-emerald-600 p-2 rounded-xl shadow-lg shadow-emerald-200">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
              </svg>
            </div>
            <h1 className="text-xl font-extrabold tracking-tight text-slate-800">Nutri<span className="text-emerald-600">Scan</span></h1>
          </div>
          
          <div className="flex items-center space-x-3">
            <span className="hidden sm:block text-xs font-bold text-slate-400 uppercase tracking-widest">Your Goal:</span>
            <select 
              value={state.goal} 
              onChange={(e) => setGoal(e.target.value as Goal)}
              className="bg-emerald-50 text-emerald-700 text-sm font-bold py-2 px-4 rounded-xl border-none focus:ring-2 focus:ring-emerald-500 shadow-sm"
            >
              {Object.values(Goal).map(g => <option key={g} value={g}>{g}</option>)}
            </select>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 mt-8">
        {!state.analysis && !state.isAnalyzing ? (
          <div className="flex flex-col items-center justify-center space-y-10 py-16 text-center">
            <div className="space-y-4 max-w-2xl">
              <h2 className="text-5xl font-black text-slate-900 leading-tight">
                Unlock the <span className="text-emerald-600">DNA</span> <br/>of your food.
              </h2>
              <p className="text-slate-500 text-lg">
                Identify vitamins, minerals, health benefits, and weight impact instantly with world-class AI vision.
              </p>
            </div>

            <div 
              onClick={() => fileInputRef.current?.click()}
              className="w-full max-w-md bg-white border-2 border-dashed border-emerald-300 rounded-[2.5rem] p-16 flex flex-col items-center justify-center cursor-pointer hover:border-emerald-500 hover:bg-emerald-50/50 transition-all group shadow-2xl shadow-emerald-100"
            >
              <div className="bg-emerald-600 p-8 rounded-full group-hover:scale-110 transition-transform shadow-xl shadow-emerald-200">
                <svg className="w-14 h-14 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              </div>
              <p className="mt-8 text-2xl font-black text-slate-800">Scan Meal</p>
              <p className="text-slate-400 mt-2 font-medium">Upload photo for instant analysis</p>
              <input 
                type="file" 
                ref={fileInputRef} 
                className="hidden" 
                accept="image/*" 
                capture="environment"
                onChange={handleFileUpload} 
              />
            </div>
          </div>
        ) : state.isAnalyzing ? (
          <Loader message="Deconstructing nutrients..." />
        ) : (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-6 duration-700">
            {/* Top Row: Main Stats */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Analysis Summary */}
              <div className="lg:col-span-2 bg-white rounded-[2rem] shadow-xl overflow-hidden border border-slate-100">
                <div className="bg-gradient-to-r from-emerald-600 to-emerald-500 px-8 py-6 text-white flex justify-between items-center">
                  <div>
                    <h3 className="text-3xl font-black">{state.analysis?.name}</h3>
                    <p className="text-emerald-50 font-medium opacity-90">{state.analysis?.description}</p>
                  </div>
                  <div className="bg-white/20 backdrop-blur-md p-4 rounded-3xl text-center border border-white/30">
                    <p className="text-[10px] uppercase font-black tracking-widest mb-1">Health Score</p>
                    <p className="text-4xl font-black">{state.analysis?.healthScore}</p>
                  </div>
                </div>

                <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-10">
                  <div className="space-y-8">
                    <div className="flex items-baseline justify-between">
                      <h4 className="text-xl font-black text-slate-800 tracking-tight">Macros</h4>
                      <span className="text-3xl font-black text-emerald-600">{state.analysis?.macros.calories} <span className="text-sm font-bold text-slate-300">kcal</span></span>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-3">
                      <div className="bg-emerald-50 p-4 rounded-2xl text-center border border-emerald-100">
                        <p className="text-[10px] text-emerald-600 font-black uppercase mb-1">Protein</p>
                        <p className="text-xl font-black text-emerald-700">{state.analysis?.macros.protein}g</p>
                      </div>
                      <div className="bg-blue-50 p-4 rounded-2xl text-center border border-blue-100">
                        <p className="text-[10px] text-blue-600 font-black uppercase mb-1">Carbs</p>
                        <p className="text-xl font-black text-blue-700">{state.analysis?.macros.carbs}g</p>
                      </div>
                      <div className="bg-amber-50 p-4 rounded-2xl text-center border border-amber-100">
                        <p className="text-[10px] text-amber-600 font-black uppercase mb-1">Fat</p>
                        <p className="text-xl font-black text-amber-700">{state.analysis?.macros.fat}g</p>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <p className="text-sm font-black text-slate-400 uppercase tracking-widest">Health Benefits</p>
                      <div className="flex flex-wrap gap-2">
                        {state.analysis?.healthBenefits.map(benefit => (
                          <span key={benefit} className="bg-emerald-50 text-emerald-700 px-4 py-2 rounded-xl text-sm font-bold border border-emerald-100 flex items-center space-x-2">
                            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
                            <span>{benefit}</span>
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col items-center justify-center bg-slate-50/50 rounded-[2rem] p-4">
                    <MacroChart data={state.analysis!.macros} />
                  </div>
                </div>
              </div>

              {/* Goal Impact Analysis */}
              <div className="bg-slate-900 rounded-[2rem] p-8 text-white shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 p-8 opacity-10">
                  <svg className="w-32 h-32" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z" />
                  </svg>
                </div>
                <h4 className="text-xl font-black mb-8 flex items-center space-x-3">
                   <span className="w-2 h-8 bg-emerald-500 rounded-full block"></span>
                   <span>Goal Impact</span>
                </h4>
                
                <div className="space-y-8 relative z-10">
                  <div className={`p-5 rounded-2xl border ${state.goal === Goal.LOSS ? 'border-emerald-500 bg-emerald-500/10' : 'border-slate-800 opacity-60'}`}>
                    <p className="text-xs font-black uppercase tracking-widest text-emerald-500 mb-2">Weight Loss</p>
                    <p className="text-sm leading-relaxed text-slate-300">{state.analysis?.weightImpact.loss}</p>
                  </div>
                  
                  <div className={`p-5 rounded-2xl border ${state.goal === Goal.GAIN ? 'border-emerald-500 bg-emerald-500/10' : 'border-slate-800 opacity-60'}`}>
                    <p className="text-xs font-black uppercase tracking-widest text-emerald-500 mb-2">Weight Gain</p>
                    <p className="text-sm leading-relaxed text-slate-300">{state.analysis?.weightImpact.gain}</p>
                  </div>

                  <div className="pt-4 border-t border-slate-800">
                    <p className="text-xs text-slate-500 italic">Analysis tailored to your current goal: <strong>{state.goal}</strong></p>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Row: Detailed Nutrients & Recommendations */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
               {/* Micronutrients Table */}
               <div className="bg-white rounded-[2rem] p-8 shadow-xl border border-slate-100 lg:col-span-1">
                 <h4 className="text-xl font-black mb-6 text-slate-800">Micronutrients</h4>
                 <div className="space-y-5">
                   {state.analysis?.micronutrients.map((micro, i) => (
                     <div key={i} className="space-y-2">
                       <div className="flex justify-between text-sm font-bold">
                         <span className="text-slate-600">{micro.name}</span>
                         <span className="text-emerald-600">{micro.amount}</span>
                       </div>
                       <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                         <div 
                          className="h-full bg-emerald-500 transition-all duration-1000 ease-out" 
                          style={{ width: `${Math.min(micro.percentDV, 100)}%` }}
                         />
                       </div>
                       <p className="text-[10px] font-black text-slate-400 text-right uppercase tracking-tighter">{micro.percentDV}% Daily Value</p>
                     </div>
                   ))}
                 </div>
               </div>

               {/* AI Recommendations */}
               <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Diet Suggestions */}
                  <div className="bg-white rounded-[2rem] p-8 shadow-xl border border-slate-100">
                    <div className="flex items-center space-x-3 mb-6">
                      <div className="bg-amber-100 p-3 rounded-2xl">
                        <svg className="w-6 h-6 text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                        </svg>
                      </div>
                      <h4 className="text-xl font-black text-slate-800">AI Diet Plan</h4>
                    </div>
                    <ul className="space-y-4">
                      {state.recommendation?.dietPlan.mealSuggestions.map((item, i) => (
                        <li key={i} className="flex items-start space-x-3 bg-slate-50 p-3 rounded-2xl border border-slate-100">
                          <span className="bg-emerald-500 text-white w-5 h-5 rounded-full flex-shrink-0 flex items-center justify-center text-[10px] font-bold mt-0.5">{i+1}</span>
                          <span className="text-slate-600 text-sm font-medium">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Exercises */}
                  <div className="bg-white rounded-[2rem] p-8 shadow-xl border border-slate-100">
                    <div className="flex items-center space-x-3 mb-6">
                      <div className="bg-blue-100 p-3 rounded-2xl">
                        <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                        </svg>
                      </div>
                      <h4 className="text-xl font-black text-slate-800">Exercises</h4>
                    </div>
                    <div className="space-y-4">
                      {state.recommendation?.exerciseRoutine.exercises.map((ex, i) => (
                        <div key={i} className="flex justify-between items-center group bg-slate-50 p-4 rounded-2xl border border-slate-100">
                          <div>
                            <p className="text-sm font-black text-slate-800">{ex.name}</p>
                            <p className="text-[10px] text-blue-600 font-bold uppercase mt-1">{ex.benefit}</p>
                          </div>
                          <span className="text-xs font-black bg-blue-600 text-white px-3 py-1.5 rounded-xl shadow-lg shadow-blue-100">
                            {ex.duration}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
               </div>
            </div>

            <div className="flex justify-center pt-8">
              <button 
                onClick={reset}
                className="bg-slate-900 text-white px-10 py-5 rounded-3xl font-black text-lg hover:bg-emerald-600 transition-all shadow-2xl flex items-center space-x-4 group"
              >
                <svg className="w-6 h-6 group-hover:rotate-180 transition-transform duration-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
                <span>Analyze New Meal</span>
              </button>
            </div>
          </div>
        )}
      </main>

      {state.error && (
        <div className="fixed bottom-10 left-1/2 -translate-x-1/2 bg-red-600 text-white px-8 py-4 rounded-3xl shadow-2xl animate-bounce font-black flex items-center space-x-3 z-[100]">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <span>{state.error}</span>
        </div>
      )}
    </div>
  );
};

export default App;
