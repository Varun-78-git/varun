
import { GoogleGenAI, Type } from "@google/genai";
import { FoodAnalysis, Goal, Recommendation } from "../types";

const API_KEY = process.env.API_KEY || "";

export const analyzeFoodImage = async (base64Image: string): Promise<FoodAnalysis> => {
  const ai = new GoogleGenAI({ apiKey: API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: base64Image,
          },
        },
        {
          text: `Identify the food in this image and provide a clinical nutritional breakdown. 
          Focus on:
          1. Macros (Cal, Protein, Carbs, Fat)
          2. Micronutrients (at least 3 key vitamins/minerals)
          3. Specific health benefits
          4. How this food specifically affects Weight Loss vs Weight Gain goals.
          
          Return a JSON object following the schema.`
        }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          description: { type: Type.STRING },
          macros: {
            type: Type.OBJECT,
            properties: {
              calories: { type: Type.NUMBER },
              protein: { type: Type.NUMBER },
              carbs: { type: Type.NUMBER },
              fat: { type: Type.NUMBER }
            },
            required: ["calories", "protein", "carbs", "fat"]
          },
          micronutrients: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                amount: { type: Type.STRING },
                percentDV: { type: Type.NUMBER }
              }
            }
          },
          healthBenefits: { type: Type.ARRAY, items: { type: Type.STRING } },
          weightImpact: {
            type: Type.OBJECT,
            properties: {
              loss: { type: Type.STRING },
              gain: { type: Type.STRING }
            }
          },
          healthScore: { type: Type.NUMBER },
          ingredients: { type: Type.ARRAY, items: { type: Type.STRING } }
        },
        required: ["name", "description", "macros", "micronutrients", "healthBenefits", "weightImpact", "healthScore", "ingredients"]
      }
    }
  });

  return JSON.parse(response.text);
};

export const getPersonalizedRecommendations = async (foodAnalysis: FoodAnalysis, goal: Goal): Promise<Recommendation> => {
  const ai = new GoogleGenAI({ apiKey: API_KEY });
  const prompt = `Based on a meal of ${foodAnalysis.name} (${foodAnalysis.description}) and the user goal: ${goal}.
  Suggest:
  1. A tailored diet plan for the rest of the day to stay on track.
  2. 3 Specific exercises to balance this meal's caloric and nutrient profile.
  Return as JSON.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          dietPlan: {
            type: Type.OBJECT,
            properties: {
              mealSuggestions: { type: Type.ARRAY, items: { type: Type.STRING } },
              tips: { type: Type.ARRAY, items: { type: Type.STRING } }
            }
          },
          exerciseRoutine: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              exercises: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    duration: { type: Type.STRING },
                    benefit: { type: Type.STRING }
                  }
                }
              }
            }
          }
        }
      }
    }
  });

  return JSON.parse(response.text);
};
