
import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { MacroData } from '../types';

interface Props {
  data: MacroData;
}

const MacroChart: React.FC<Props> = ({ data }) => {
  const chartData = [
    { name: 'Protein', value: data.protein * 4, color: '#10B981' },
    { name: 'Carbs', value: data.carbs * 4, color: '#3B82F6' },
    { name: 'Fat', value: data.fat * 9, color: '#F59E0B' },
  ];

  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={chartData}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={80}
            paddingAngle={5}
            dataKey="value"
          >
            {chartData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Pie>
          <Tooltip 
            formatter={(value: number) => [`${value.toFixed(0)} kcal`, 'Calories']}
            contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
          />
          <Legend verticalAlign="bottom" height={36}/>
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

export default MacroChart;
