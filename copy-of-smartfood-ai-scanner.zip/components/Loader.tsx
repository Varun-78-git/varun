
import React from 'react';

const Loader: React.FC<{ message?: string }> = ({ message = "Analyzing nutritional data..." }) => {
  return (
    <div className="flex flex-col items-center justify-center p-12 space-y-4">
      <div className="relative">
        <div className="w-16 h-16 border-4 border-emerald-100 border-t-emerald-600 rounded-full animate-spin"></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-8 h-8 bg-emerald-500 rounded-full animate-pulse"></div>
        </div>
      </div>
      <p className="text-emerald-700 font-medium animate-pulse">{message}</p>
    </div>
  );
};

export default Loader;
