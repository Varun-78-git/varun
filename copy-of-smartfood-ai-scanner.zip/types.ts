
export enum Goal {
  LOSS = 'Weight Loss',
  GAIN = 'Weight Gain',
  MAINTAIN = 'Maintain Health'
}

export interface MacroData {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export interface Micronutrient {
  name: string;
  amount: string;
  percentDV: number; // Percent Daily Value
}

export interface FoodAnalysis {
  name: string;
  description: string;
  macros: MacroData;
  micronutrients: Micronutrient[];
  healthBenefits: string[];
  weightImpact: {
    loss: string;
    gain: string;
  };
  healthScore: number;
  ingredients: string[];
}

export interface Recommendation {
  dietPlan: {
    mealSuggestions: string[];
    tips: string[];
  };
  exerciseRoutine: {
    title: string;
    exercises: {
      name: string;
      duration: string;
      benefit: string;
    }[];
  };
}

export interface AppState {
  isAnalyzing: boolean;
  goal: Goal;
  analysis: FoodAnalysis | null;
  recommendation: Recommendation | null;
  error: string | null;
}
